<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeCv extends Model
{
    protected $table = 'tbl_emp_basic_info';
}
