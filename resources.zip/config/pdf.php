<?php

return [
	// ...
	'font_path' => base_path('resources/fonts/'),
	'font_data' => [
		"nikosh" => array(
		'R' => "Nikosh.ttf",
		'useOTL' => 0xFF,       
		), 
		// ...add as many as you want.
	]
	// ...
];
