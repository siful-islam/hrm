/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'fi', {
	block: 'Tasaa molemmat reunat',
	center: 'Keskitä',
	left: 'Tasaa vasemmat reunat',
	right: 'Tasaa oikeat reunat'
} );
