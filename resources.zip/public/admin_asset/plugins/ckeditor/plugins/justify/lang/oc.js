/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'oc', {
	block: 'Justificar',
	center: 'Centrar',
	left: 'Alinhar a esquèrra',
	right: 'Alinhar a dreita'
} );
